export default class Resource {
  constructor(client) {
    this.graphQLClient = client;
  }
}
