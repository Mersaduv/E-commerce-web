export default {
  "data": {
    "node": null
  }
};
