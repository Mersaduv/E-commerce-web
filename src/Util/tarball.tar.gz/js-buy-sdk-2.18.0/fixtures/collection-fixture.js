export default {
  "data": {
    "node": {
      "id": "gid://shopify/Product/7857989384",
      "handle": "frontpage",
      "updatedAt": "2017-01-16T15:49:34Z",
      "title": "Cat Collection",
      "image": null
    }
  }
}
