export default {
  "data": {
    "nodes": [
      {
        "id": "gid://shopify/Product/7857989384",
      }, {
        "id": "Z2lkOi8vc2hvcGlmeS9Qcm9kdWN0Lzc4NTc5ODkzOTE=",
      }
    ]
  }
};
