export default {
  "data": {
    "collectionByHandle": {
      "id": "Z2lkOi8vc2hvcGlmeS9Db2xsZWN0aW9uLzM2NDAxNTk0Mg==",
      "title": "Sneakers",
      "products": {
        "pageInfo": {
          "hasNextPage": false,
          "hasPreviousPage": false
        },
        "edges": [
          {
            "node": {
              "id": "Z2lkOi8vc2hvcGlmeS9Qcm9kdWN0LzkyODY5OTM5MjY=",
              "title": "The Bab Low",
              "handle": "the-bab-low"
            }
          },
          {
            "node": {
              "id": "Z2lkOi8vc2hvcGlmeS9Qcm9kdWN0LzkyODc0NzIzOTA=",
              "title": "The G-knit",
              "handle": "the-g-knit"
            }
          },
          {
            "node": {
              "id": "Z2lkOi8vc2hvcGlmeS9Qcm9kdWN0LzkyODc0NDAyNjI=",
              "title": "The Royale",
              "handle": "the-royale"
            }
          }
        ]
      }
    }
  }
}
