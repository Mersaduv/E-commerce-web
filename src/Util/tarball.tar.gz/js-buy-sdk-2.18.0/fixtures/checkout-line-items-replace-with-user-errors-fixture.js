export default {
  "data": {
    "checkoutLineItemsReplace": {
      "userErrors": [
        {
          "message": "Variant is invalid",
          "field": ['lineItems', '0', 'variantId'],
          "code": "INVALID"
        }
      ],
      "checkout": null
    }
  }
};
