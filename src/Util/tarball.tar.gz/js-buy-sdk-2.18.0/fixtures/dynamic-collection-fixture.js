export default {
  "data": {
    "node": {
      "id": "gid://shopify/Product/7857989384",
      "title": "Cat Collection",
      "updatedAt": "2017-01-16T15:49:34Z",
      "image": null
    }
  }
}
