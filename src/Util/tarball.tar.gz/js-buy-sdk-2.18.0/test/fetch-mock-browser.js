export {default} from 'fetch-mock/es5/client';
