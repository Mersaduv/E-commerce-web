export default {
  "data": {
    "checkoutEmailUpdateV2": {
      "checkoutUserErrors": [
        {
          "message": "Email is invalid",
          "field": ['email'],
          "code": "INVALID"
        }
      ],
      "userErrors": [
        {
          "message": "Email is invalid",
          "field": ['email'],
        }
      ],
      "checkout": null
    }
  }
};
