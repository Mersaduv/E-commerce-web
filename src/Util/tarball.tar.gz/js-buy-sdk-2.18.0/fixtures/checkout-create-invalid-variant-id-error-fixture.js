export default {
  "errors": [
    {
      "message": "Variable input of type CheckoutCreateInput! was provided invalid value"
    }
  ]
}
