export {default} from 'fetch-mock';
