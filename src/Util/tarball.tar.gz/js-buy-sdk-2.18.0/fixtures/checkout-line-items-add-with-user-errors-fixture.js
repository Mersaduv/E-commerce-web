export default {
  "data": {
    "checkoutLineItemsAdd": {
      "userErrors": [
        {
          "message": "Variant is invalid",
          "field": ["lineItems", "0", "variantId"]
        }
      ],
      "checkoutUserErrors": [
        {
          "message": "Variant is invalid",
          "field": ["lineItems", "0", "variantId"],
          "code": "INVALID"
        },
      ],
      "checkout": null
    }
  }
};
