export default {
  "data": {
    "collections": {
      "pageInfo": {
        "hasNextPage": false,
        "hasPreviousPage": false
      },
      "edges": [
        {
          "cursor": "eyJsYXN0X2lkIjozNjkzMTI1ODQsImxhc3RfdmFsdWUiOiIzNjkzMTI1ODQifQ==",
          "node": {
            "id": "gid://shopify/Product/7857989384",
            "handle": "frontpage",
            "updatedAt": "2017-01-16T15:49:34Z",
            "title": "Cat Collection",
            "image": null
          }
        },
        {
          "cursor": "eyJsYXN0X2lkIjo0MTMwOTQ0NzIsImxhc3RfdmFsdWUiOiI0MTMwOTQ0NzIifQ==",
          "node": {
            "id": "gid://shopify/Product/8530033544",
            "handle": "test",
            "updatedAt": "2017-01-16T15:51:51Z",
            "title": "Test",
            "image": null
          }
        }
      ]
    }
  }
};
