export {default} from 'graphql-js-client';
