export default {
  "data": {
    "shop": {
      "privacyPolicy": {
        "id": "gid://shopify/ProductImage/20143041864",
        "title": "Privacy Policy",
        "url": "https://checkout.shopify.com/15107238/policies/2310921.html",
        "body": "privacy things"
      },
      "termsOfService": {
        "id": "gid://shopify/Product/7857989384",
        "title": "Terms of Service",
        "url": "https://checkout.shopify.com/15107238/policies/2341235.html",
        "body": "terms of service things"
      },
      "refundPolicy": {
        "id": "gid://shopify/Product/7857989384",
        "title": "Refund Policy",
        "url": "https://checkout.shopify.com/15107238/policies/13412543.html",
        "body": "refund things"
      }
    }
  }
};
