setup(() => {
  if (typeof mocha !== 'undefined') {
    mocha.setup({
      globals: ['LiveReload']
    });
  }
});
